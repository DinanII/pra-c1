# pra-c1
Deze praktijkopdracht staat in het teken van de open avond avond van de opleiding Software Developer in Roosendaal. Het is een onepage website die dient als samenvatting, zodat de aspirant studenten alle belangrijke informatie omtrent de open avond na kunnen lezen
en staan er een aantal links naar handige websites waar studenten zich alvast kunnnen inlezen over o.a. Python, HTML en zich kunnen aanmelden. Omdat de website gemaakt is door een begin-tweedejaars, weten de (aspirant) studenten naar een jaar kunnen.
